#!/bin/sh
java  -jar Space Rocket.jar
        